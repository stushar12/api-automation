package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class AnalyticsView extends PageCost{

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();

	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>uwTeamsCompleteList = new ArrayList<ArrayList<String>>();
		uwTeamsCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetTeamDetails", "CustomQueryTeamDetails", "117", "EF"));
		uwTeamsCompleteList.add(addValueToList("GET", "/uw-info/teams", "teamInfo", "117", "UI"));
		nodeEndpoints.put("uwTeamsCompleteList",uwTeamsCompleteList);

		ArrayList<ArrayList<String>>lobCompleteList = new ArrayList<ArrayList<String>>();
		lobCompleteList.add(addValueToList("GET", "/uda-ef/Cituarb1LobMst", "Cituarb1LobMst", "14", "EF"));
		lobCompleteList.add(addValueToList("GET", "ref-data/lob", "refDataLob", "14", "UI"));
		nodeEndpoints.put("lobCompleteList",lobCompleteList);

		ArrayList<ArrayList<String>>uwBranchCompleteList = new ArrayList<ArrayList<String>>();
		uwBranchCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetBranchDetails", "CustomQueryBranchDetails", "37", "EF"));
		uwBranchCompleteList.add(addValueToList("GET", "/uw-info/branches", "branchInfo", "37", "UI"));
		nodeEndpoints.put("uwBranchCompleteList",uwBranchCompleteList);

		ArrayList<ArrayList<String>>uwGetUserTeamCompleteList = new ArrayList<ArrayList<String>>();
		uwGetUserTeamCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetTeamAndTeamMembers", "CustomQueryTeamAndTeamMembers", "267", "EF"));
		uwGetUserTeamCompleteList.add(addValueToList("GET", "/uw-info/getUserTeams", "userTeamInfo", "267", "UI"));
		nodeEndpoints.put("uwGetUserTeamCompleteList",uwGetUserTeamCompleteList);

		ArrayList<ArrayList<String>>GAloginCompleteList = new ArrayList<ArrayList<String>>();
		GAloginCompleteList.add(addValueToList("POST", "/google-analytics/getGoogleAnalytics", "loginEventGA", "NA", "UI"));
		nodeEndpoints.put("GAloginCompleteList",GAloginCompleteList);

		ArrayList<ArrayList<String>>GAclickCompleteList = new ArrayList<ArrayList<String>>();
		GAclickCompleteList.add(addValueToList("POST", "/google-analytics/getGoogleAnalytics", "clickEventGA", "NA", "UI"));
		nodeEndpoints.put("GAclickCompleteList",GAclickCompleteList);

		ArrayList<ArrayList<String>>analyticsCompleteList = new ArrayList<ArrayList<String>>();
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/ActiveBranchDetails", "activeBranchDetails", "3", "EF"));
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/SubmsByLob/mgrId/ /branch/ /regnName/ /startDate/2021-10-01/endDate/2022-03-25/lobName/", "SubmsByLobmgrId", "9", "EF"));
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/SubmsStatRecdClWip/mgrId/ /branch/ /regnName/ /startDate/2021-10-01/endDate/2022-03-25/lobName/", "SubmsStatRecdClWip", "4", "EF"));
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/SICUpdtClWipToCInsight/mgrId/ /branch/ /regnName/ /startDate/2021-10-01/endDate/2022-03-25/lobName/", "SICUpdtClWipToCInsight", "9", "EF"));
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/SICUpdtCInsightToClWip/mgrId/ /branch/ /regnName/ /startDate/2021-10-01/endDate/2022-03-25/lobName/", "SICUpdtCInsightToClWip", "4", "EF"));
		analyticsCompleteList.add(addValueToList("GET", "/uda-ef/KPI/P360LocsAddedClWip/mgrId/ /branch/ /regnName/ /startDate/2021-10-01/endDate/2022-03-25/lobName/", "P360LocsAddedClWip", "2", "EF"));
		analyticsCompleteList.add(addValueToList("POST", "/analytics", "analyticsBasedOnFilter", "NA", "UI"));
		nodeEndpoints.put("analyticsCompleteList",analyticsCompleteList);


		calculateCost(nodeEndpoints,"AnalyticsView",1); // increase the counter by one everytime you call this function.

	}

}
