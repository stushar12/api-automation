package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class RES extends PageCost{

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>getExposuresCompleteList = new ArrayList<ArrayList<String>>();
		getExposuresCompleteList.add(addValueToList("GET", "/uda-ef/Citua131RskEngmntOp/sbmsnId/b1f6ad05-2538-433e-96aa-f70850fe4723/sbmsnAddrId/1abd1d79-d8de-4b9c-a36a-b6becdd6eda9", "Citua131RskEngmntOp","4","EF"));
		getExposuresCompleteList.add(addValueToList("GET", "/ree-tool/getExposures?sbmsnId=4f5874ec-2c59-4198-8371-87e38028ad1b&sbmsnAddrId=922e3f0e-d21b-4c7c-a324-f7cd8d651319", "savedExposureValues","3","UI"));

		nodeEndpoints.put("getExposuresCompleteList",getExposuresCompleteList);

		ArrayList<ArrayList<String>>sicCodelobCodeCompleteList = new ArrayList<ArrayList<String>>();
		sicCodelobCodeCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/RskEngmntChrctrstc/siccode/5012/lobcode/PROP", "CustomQuery","1","EF"));
		sicCodelobCodeCompleteList.add(addValueToList("GET", "/ree-tool/siccode/5141/lobcode/GL", "resUtilization","1","UI"));

		nodeEndpoints.put("sicCodelobCodeCompleteList",sicCodelobCodeCompleteList);

		ArrayList<ArrayList<String>>saveAuditReportCompleteList = new ArrayList<ArrayList<String>>();
		saveAuditReportCompleteList.add(addValueToList("POST", "/uda-ef/Citua131RskEngmntOp", "CustomQuery","NA","EF"));
		saveAuditReportCompleteList.add(addValueToList("POST", "/ree-tool/saveAuditReport", "savesAuditReport","NA","UI"));

		nodeEndpoints.put("saveAuditReportCompleteList",saveAuditReportCompleteList);

		calculateCost(nodeEndpoints,"RES",1);    // increase the counter by one everytime you call this function.
	}

}
