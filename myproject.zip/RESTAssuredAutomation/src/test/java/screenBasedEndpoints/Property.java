package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class Property extends PageCost {

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>detailedComparativeCompleteList = new ArrayList<ArrayList<String>>();
		detailedComparativeCompleteList.add(addValueToList("GET", "/uda-ef/Cituar61User/chbemailid/suddin@chubb.com", "Cituar61User","1","EF"));
		detailedComparativeCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetTeamInfoForManager/mgrId/5b990f52-4230-431a-a43c-0310cc15a08f", "GetTeamInfoForManager","0","EF"));
		detailedComparativeCompleteList.add(addValueToList("POST", "/uda-ef/CustomQuery/CreateNewTeam", "createNewTeam","NA","EF"));
		detailedComparativeCompleteList.add(addValueToList("GET", "/uda-ef/Citua001Sbmsn/d7e4d06a-215d-4640-917f-0003e7e02709", "Citua001Sbmsn","1","EF"));
		detailedComparativeCompleteList.add(addValueToList("PUT", "/uda-ef/Citua001Sbmsn/08466a5e-0ca1-4744-b721-f80b034dca71", "Citua001Sbmsn","NA","EF"));
		detailedComparativeCompleteList.add(addValueToList("PUT", "/uda-ef/Citua071SbmsnLob/f420ec70-1556-49fa-abbe-000b566e947d", "Citua071SbmsnLob", "NA", "EF"));
		detailedComparativeCompleteList.add(addValueToList("POST", "/uda-ef/Citua071SbmsnLob", "Citua071SbmsnLob","NA","EF"));
		detailedComparativeCompleteList.add(addValueToList("GET", "/uda-ef/Citua111SbmsnUserXref/sbmsnId/28f39336-db51-4672-885b-f738b56e41ff", "Citua111SbmsnUserXref", "NA", "EF"));
		detailedComparativeCompleteList.add(addValueToList("POST", "/uda-ef/Citua111SbmsnUserXref", "Citua111SbmsnUserXref", "NA", "EF"));
		detailedComparativeCompleteList.add(addValueToList("PUT", "/submission", "updateSubmissionDetails", "NA", "UI"));

		nodeEndpoints.put("detailedComparativeCompleteList",detailedComparativeCompleteList);


		ArrayList<ArrayList<String>>tensorflightCompleteList = new ArrayList<ArrayList<String>>();
		tensorflightCompleteList.add(addValueToList("POST", "/uda-ef/Citua031ApiCallDtls", "Citua031ApiCallDtls","NA","EF"));
		tensorflightCompleteList.add(addValueToList("POST", "/uda-ef/Citua091ApiSbmsnXref", "Citua091ApiSbmsnXref","NA","EF"));
		tensorflightCompleteList.add(addValueToList("POST", "/uda-ef/Citua101ApiSbmsnAddrXref", "Citua101ApiSbmsnAddrXref","NA","EF"));
		tensorflightCompleteList.add(addValueToList("POST", "/tensor-flight/details", "tensorflightDetails","NA","UI"));

		nodeEndpoints.put("tensorflightCompleteList",tensorflightCompleteList);

		calculateCost(nodeEndpoints,"Property", 1);  // increase the counter by one everytime you call this function.
	}

}
