package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class UW_Questions extends PageCost{

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>UWQuestionCompleteList = new ArrayList<ArrayList<String>>();
		UWQuestionCompleteList.add(addValueToList("POST", "/uda-ef/Citua121SbmsnQues", "Citua121SbmsnQues", "NA", "EF"));
		UWQuestionCompleteList.add(addValueToList("POST", "/uw-qstns", "savesQuesAns", "NA", "UI"));

		nodeEndpoints.put("detailedComparativeCompleteList",UWQuestionCompleteList);

		calculateCost(nodeEndpoints,"UW_Questions",1);   // increase the counter by one everytime you call this function.
	}

}
