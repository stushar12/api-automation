package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class landingPage extends PageCost {


	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}

	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>uwinfoCompleteList = new ArrayList<ArrayList<String>>();
		uwinfoCompleteList.add(addValueToList("GET", "/uda-ef/Cituar61User/chbemailid/suddin@chubb.com", "Cituar61User","1","EF"));
		uwinfoCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetTeamInfoForManager/mgrId/5b990f52-4230-431a-a43c-0310cc15a08f", "GetTeamInfoForManager","0","EF"));
		uwinfoCompleteList.add(addValueToList("POST", "/uda-ef/CustomQuery/CreateNewTeam", "createNewTeam","NA","EF"));
		uwinfoCompleteList.add(addValueToList("GET", "/uw-info", "uwinfo","1","UI"));
		nodeEndpoints.put("uwinfo",uwinfoCompleteList);


		ArrayList<ArrayList<String>>submissionCompleteList = new ArrayList<ArrayList<String>>();
		submissionCompleteList.add(addValueToList("GET", "/uda-ef/Cituar61User/chbemailid/suddin@chubb.com", "Cituar61User","1","EF"));
		submissionCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GetTeamInfoForManager/mgrId/5b990f52-4230-431a-a43c-0310cc15a08f", "GetTeamInfoForManager","0","EF"));
		submissionCompleteList.add(addValueToList("POST", "/uda-ef/CustomQuery/CreateNewTeam", "createNewTeam","NA","EF"));
		submissionCompleteList.add(addValueToList("GET", "/uda-ef/Citua141OffrgStatLog", "Citua141OffrgStatLog","9674","EF"));
		submissionCompleteList.add(addValueToList("GET", "/uda-ef/Citua001Sbmsn/withChildEntitiesForUser/5b990f52-4230-431a-a43c-0310cc15a08f", "Citua001Sbmsn","1","EF"));
		submissionCompleteList.add(addValueToList("GET", "/submission", "submission", "1", "UI"));
		nodeEndpoints.put("submission",submissionCompleteList);

		ArrayList<ArrayList<String>>refDataLobCompleteList = new ArrayList<ArrayList<String>>();
		refDataLobCompleteList.add(addValueToList("GET", "/uda-ef/Cituarb1LobMst", "Cituarb1LobMst","14","EF"));
		refDataLobCompleteList.add(addValueToList("GET","/ref-data/lob", "refDataLob", "14", "UI"));
		nodeEndpoints.put("refDataLob", refDataLobCompleteList);


		ArrayList<ArrayList<String>>envCompleteList = new ArrayList<ArrayList<String>>();
		envCompleteList.add(addValueToList("GET", "/env", "env", "4", "UI"));
		nodeEndpoints.put("envCompleteList", envCompleteList);
		
		calculateCost(nodeEndpoints,"LandingPage",1);   // increase the counter by one everytime you call this function.
	}

}
