package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class Google extends PageCost {

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>autoCompleteList = new ArrayList<ArrayList<String>>();
		autoCompleteList.add(addValueToList("GET", "/google/place/autocomplete?input=3200&type=address", "googleAutocomplete","2","UI"));
		nodeEndpoints.put("autocomplete",autoCompleteList);


		ArrayList<ArrayList<String>>googleLocationCompleteList = new ArrayList<ArrayList<String>>();
		googleLocationCompleteList.add(addValueToList("GET", "/google/place?query=%203000%20New%20Bern%20Avenue,%20Raleigh,%20NC,%20USA", "googleLocation","3","UI"));
		nodeEndpoints.put("googleLocation",googleLocationCompleteList);


		ArrayList<ArrayList<String>>addLocation = new ArrayList<ArrayList<String>>();
		addLocation.add(addValueToList("POST", "/uda-ef/Citua051SbmsnAddr", "Citua051SbmsnAddr","NA","EF"));
		addLocation.add(addValueToList("POST", "/submission/address", "addProperty","NA","UI"));
		nodeEndpoints.put("addLocation",addLocation);

		ArrayList<ArrayList<String>>updateLocation = new ArrayList<ArrayList<String>>();
		updateLocation.add(addValueToList("PUT", "/uda-ef/Citua051SbmsnAddr/b86049cd-c6f6-4655-a738-cfb3b40d5517", "Citua051SbmsnAddr","NA","EF"));
		updateLocation.add(addValueToList("PUT", "/submission/address/84395c50-abd1-4a99-9252-85357e3b9f4c", "updateSubmissionAddressDetails","NA","UI"));
		nodeEndpoints.put("updateLocation",updateLocation);


		ArrayList<ArrayList<String>>submissionAddressCompleteList = new ArrayList<ArrayList<String>>();
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Citua051SbmsnAddr/sbmsnId/28f39336-db51-4672-885b-f738b56e41ff", "Citua051SbmsnAddr","6","EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Citua091ApiSbmsnXref/sbmsnId/e71c3011-9298-491a-8668-b94573a81e3b", "Citua091ApiSbmsnXref", "281", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Citua101ApiSbmsnAddrXref/sbmsnAddrId/5602f54f-b55b-4840-9cf3-e7729897f138", "Citua101ApiSbmsnAddrXref", "227", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Citua031ApiCallDtls/a4dd4367-60e5-4749-ada2-001b200913ed", "Citua031ApiCallDtls", "1", "EF"));
		submissionAddressCompleteList.add(addValueToList("POST", "/uda-p360/location", "locationP360","NA","P360"));
		submissionAddressCompleteList.add(addValueToList("POST", "/uda-ef/Citua031ApiCallDtls", "Citua031ApiCallDtls","NA","EF"));
		submissionAddressCompleteList.add(addValueToList("POST", "/uda-p360/pitneybowes", "pitneyBowesP360", "NA", "P360"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Cituar51HzrdZipFlag", "Cituar51HzrdZipFlag", "43712", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/CustomQuery/GuidpointSrvy/cbLocId/P00005K4L9AP", "CustomQueryGuidpointSrvy", "1", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Cituard1EasiDermoInfo/zipcode/07034", "Cituard1zipcode", "11", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Cituard1EasiDermoInfo/easiBlkNum/340270417024", "Cituard1easiBlkNum", "1", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/uda-ef/Cituard1EasiDermoInfo/easitractnnum/34027041702", "Cituard1easitractnnum", "5", "EF"));
		submissionAddressCompleteList.add(addValueToList("GET", "/submission/address/d471741e-941f-47c1-ac9d-fd7b0a8657bb", "submissionAddressDetails", "8", "UI"));
		nodeEndpoints.put("submissionAddressCompleteList",submissionAddressCompleteList);

		calculateCost(nodeEndpoints,"Google",1);  // increase the counter by one everytime you call this function.
	}

}
