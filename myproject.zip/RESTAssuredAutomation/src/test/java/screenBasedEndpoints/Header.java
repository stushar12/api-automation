package screenBasedEndpoints;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.testng.annotations.Test;

import testing_InCight.PageCost;

public class Header extends PageCost {

	LinkedHashMap<String, ArrayList<ArrayList<String>>> nodeEndpoints = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();


	ArrayList<String> addValueToList(String HTTP_Method, String endpoint, String filename,String object_count,String source)
	{		
		ArrayList<String>api = new ArrayList<String>();
		api.add(HTTP_Method);
		api.add(endpoint);
		api.add(filename);
		api.add(object_count);
		api.add(source);
		return api;
	}


	@Test
	void addEndpoints() {

		ArrayList<ArrayList<String>>submissionDetailsCompleteList = new ArrayList<ArrayList<String>>();
		submissionDetailsCompleteList.add(addValueToList("GET", "/uda-ef/Citua001Sbmsn/WithChildEntities/4f5874ec-2c59-4198-8371-87e38028ad1b", "Citua001SbmsnWithChildEntities","1","EF"));
		submissionDetailsCompleteList.add(addValueToList("GET", "/uda-ef/Citua051SbmsnAddr/sbmsnId/28f39336-db51-4672-885b-f738b56e41ff", "Citua051SbmsnAddr","6","EF"));
		submissionDetailsCompleteList.add(addValueToList("PUT", "/uda-ef/Citua081SbmsnStatLog/92c603f5-8a88-412e-ad3b-002ebec23e1f", "Citua081SbmsnStatLog","NA","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-p360/prospects", "prospectsP360","NA","P360"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-p360/prospect", "prospectP360","NA","P360"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-p360/location", "locationP360","NA","P360"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/vendorintegration/D4/crawldataorchestration", "d4Crawl","NA","D4"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-ef/Citua031ApiCallDtls", "Citua031ApiCallDtls","NA","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-ef/Citua091ApiSbmsnXref", "Citua091ApiSbmsnXref","NA","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/uda-ef/Citua101ApiSbmsnAddrXref", "Citua101ApiSbmsnAddrXref","NA","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/bzops-summary/run", "bzopsSummary","NA","External"));
		submissionDetailsCompleteList.add(addValueToList("GET", "/uda-ef/Cituar61User/lanid/TUSAXEN", "Cituar61User","1","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/sic-bert/encode", "sicbert","NA","External"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/sic-bow/run", "sicbow","NA","External"));
		submissionDetailsCompleteList.add(addValueToList("PUT", "/uda-ef/Citua001Sbmsn/08466a5e-0ca1-4744-b721-f80b034dca71", "Citua001Sbmsn","NA","EF"));
		submissionDetailsCompleteList.add(addValueToList("POST", "/prob-quote/predict", "probquote","NA","External"));
		submissionDetailsCompleteList.add(addValueToList("GET", "/uda-ef/Citua121SbmsnQues/getQAndAForSbmsnIdAndQuesCode/77bfad0d-58ba-48d3-ab4b-849c28fd169b/58", "Citua121SbmsnQues","39","EF"));
		submissionDetailsCompleteList.add(addValueToList("GET", "/submission/28f39336-db51-4672-885b-f738b56e41ff?refresh=true&p360Id=undefined&noP360AddressFound=false", "submissionDetailsRefreshTrue","13","UI"));


		nodeEndpoints.put("submissionDetailsCompleteList",submissionDetailsCompleteList);

		ArrayList<ArrayList<String>>submissionbyIDCompleteList = new ArrayList<ArrayList<String>>();
		submissionbyIDCompleteList.add(addValueToList("GET", "/uda-ef/Citua001Sbmsn/WithChildEntities/4f5874ec-2c59-4198-8371-87e38028ad1b", "Citua001SbmsnWithChildEntities","1","EF"));
		submissionbyIDCompleteList.add(addValueToList("GET", "/submission/id/4f5874ec-2c59-4198-8371-87e38028ad1b", "submissionDetailsParticularId","5","UI"));

		nodeEndpoints.put("submissionbyIDCompleteList",submissionbyIDCompleteList);

		calculateCost(nodeEndpoints,"Header",1);  // increase the counter by one everytime you call this function.
	}


}
