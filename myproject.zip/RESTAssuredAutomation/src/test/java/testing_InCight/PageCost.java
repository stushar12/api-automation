package testing_InCight;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PageCost{

	LinkedHashMap<Boolean, String> output= new LinkedHashMap<Boolean, String>();
	Logger logger = Logger.getLogger("InCight testing log");

	boolean validateNumberOfObjects(String endpoint,String expectedSize,String source)
	{
		baseURI="";

		if(source.compareTo("EF")==0)
		{
			baseURI="https://aip-na-cia-sit.chubbdigital.com";
		}
		else if(source.compareTo("UI")==0)
		{
			baseURI="http://localhost:1337/api/";
		}
		boolean result=false;

		Response res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation())).get(endpoint);
		JsonPath jp = new JsonPath(res.asString());
		String size=expectedSize;
		try
		{
			size=jp.get("data.size()").toString();
			result=true;
		}
		catch (Error error) {
			logger.warning(error.getMessage());
			if(expectedSize.compareTo(size)==0)
				result=true;

			logger.info("Expected count: "+expectedSize+ "\t"+ "Actual count: "+size);
			return result;
		}
		catch (Exception exception) {
			logger.warning(exception.getMessage());
			if(expectedSize.compareTo(size)==0)
				result=true;

			logger.info("Expected count: "+expectedSize+ "\t"+ "Actual count: "+size);
			return result;
		}
		if(expectedSize.compareTo(size)==0)
			result=true;

		logger.info("Expected count: "+expectedSize+ "\t"+ "Actual count: "+size);
		return result;
	}

	boolean validateDataTypeAndMissingField(String endpoint,String schemaName,String source,String screen)throws Error
	{
		baseURI="";

		if(source.compareTo("EF")==0)
		{
			baseURI="https://aip-na-cia-sit.chubbdigital.com";
		}
		else if(source.compareTo("UI")==0)
		{
			baseURI="http://localhost:1337/api/";
		}

		boolean result=false;

		Response res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation())).get(endpoint);
		try {
			res.then().assertThat().body(matchesJsonSchemaInClasspath("NodeEndpoints/"+screen+"/"+schemaName+"GET.json"));
			result=true;
		} catch (Error error) {
			logger.warning(error.getMessage());
			return result;
		}
		catch (Exception exception) {
			logger.warning(exception.getMessage());
			return result;
		}

		return result;
	}

	long performanceTesting(String endpoint,String httpMethod,String source, String screen, String filename)
	{
		Response res=null;
		baseURI="";

		File body= new File(System.getProperty("user.dir")+"/target/classes/NodeEndpoints/"+screen+"/"+filename+httpMethod+".json");


		if(source.compareTo("P360")==0)
		{
			baseURI="https://login.microsoftonline.com/chubbgroup.onmicrosoft.com/oauth2/token";
			res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation())).
					contentType("application/x-www-form-urlencoded; charset=utf-8").
					formParam("client_id", "57e48cec-ebee-4f9f-9ffc-7670b2b77918").
					formParam("client_secret", "co57Q~qs2tdGjpH5xw64ou8TphqL-V2TrASZ9").
					formParam("resource", "51dd74fe-fdce-40c3-9e62-b203e6d730c0").
					formParam("grant_type", "client_credentials").
					when().
					post();

			JsonPath jsonPathEvaluator = res.jsonPath();
			String token = jsonPathEvaluator.get("access_token");

			baseURI="https://nasit.chubbdigital.com/digital.operations.uda";

			res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation()))
					.header("Authorization", "Bearer "+token).
					header("Ocp-Apim-Subscription-Key","f92d1cf1b2684947949db5ed8c53caab").
					header("apiVersion","1").
					contentType(ContentType.JSON).
					accept(ContentType.JSON).
					body(body).
					when().
					post(endpoint);	

		}
		else
		{
			if(source.compareTo("EF")==0 || source.compareTo("External")==0)
			{
				baseURI="https://aip-na-cia-sit.chubbdigital.com";
			}
			else if(source.compareTo("UI")==0)
			{
				baseURI="http://localhost:1337/api/";
			}
			else if(source.compareTo("D4")==0)
			{
				baseURI="https://aip-na-p360-sit.chubbdigital.com";
			}


			if(httpMethod.compareTo("GET")==0)
			{
				res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation())).get(endpoint);
			}
			else
			{


				if(httpMethod.compareTo("POST")==0)
				{
					res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation()))
							.header("Content-Type","application/json").
							contentType(ContentType.JSON).
							accept(ContentType.JSON).
							body(body).
							when().
							post(endpoint);	
				}
				else if(httpMethod.compareTo("PUT")==0)
				{
					res=given().config(RestAssured.config().sslConfig(new SSLConfig().relaxedHTTPSValidation()))
							.header("Content-Type","application/json").
							contentType(ContentType.JSON).
							accept(ContentType.JSON).
							body(body).
							when().
							put(endpoint);	
				}

			}

		}

		int statusCode= res.getStatusCode();
		long ResponseTime=0;

		if(statusCode>=200 && statusCode<=299)
			ResponseTime=res.getTimeIn(TimeUnit.MILLISECONDS);

		logger.info("Response Time: "+ResponseTime+"ms" + " Status Code: "+statusCode+"\n\n");
		return ResponseTime;
	}


	public void calculateCost(LinkedHashMap<String,ArrayList<ArrayList<String>>> nodeEndpoints,String screen,int logFileCount) {

		try
		{
			FileHandler	fh = new FileHandler(System.getProperty("user.dir")+"/target/classes/Logs/"+screen+"/logFile"+logFileCount+".log");  
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter(); 
			fh.setFormatter(formatter);

			output.put(true, "PASS");
			output.put(false, "FAIL");
			for(String itr: nodeEndpoints.keySet())
			{
				int count = 0;
				long endpointCost=0;
				long totalCost=0;
				ArrayList<ArrayList<String>> result = nodeEndpoints.get(itr);
				logger.info(itr+" started\n");

				for(ArrayList<String> arr:result)
				{
					try
					{

						count++;
						String httpMethod=arr.get(0);
						String url=arr.get(1);
						String filename=arr.get(2);
						String object_count=arr.get(3);
						String source=arr.get(4);

						logger.info("Endpoint is ==> "+url);
						if(httpMethod.compareTo("GET")==0)
						{
							boolean validateDataTypeResult=validateDataTypeAndMissingField(url,filename,source,screen);
							logger.info("Struture and data_type test: "+output.get(validateDataTypeResult));

							boolean validateObjectResult=validateNumberOfObjects(url,object_count,source);
							logger.info("Number of records test: "+output.get(validateObjectResult));
						}	

						totalCost = performanceTesting(url, httpMethod, source, screen, filename);

						if(count!=result.size())
						{
							endpointCost+=totalCost;
						}
					}
					catch (Exception exp) {
						logger.warning(exp.getMessage());
					}
				}

				logger.info("Total endpoint Cost is: "+endpointCost+"ms\n");
				logger.info(itr+" ended\n");
			}
		}
		catch (Exception e) {  
			e.printStackTrace();
		}
	}

}
